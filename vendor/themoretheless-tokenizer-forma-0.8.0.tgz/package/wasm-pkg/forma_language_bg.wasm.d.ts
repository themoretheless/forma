/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const operation_json: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
export const parse_expression_json: (a: number, b: number, c: number) => void;
export const parse_json: (a: number, b: number, c: number, d: number) => void;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export3: (a: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export4: (a: number, b: number, c: number) => void;
