//! Public retained-document binding workload; prints raw timings as JSON.
use forma::{
    form_document::{Document, Properties, Value},
    Runtime,
};
use std::{
    alloc::{GlobalAlloc, Layout, System},
    cell::Cell,
};
use std::{collections::BTreeMap, time::Instant};
struct Counting;
thread_local! { static ALLOCS: Cell<Option<(usize, u64)>> = const { Cell::new(None) }; }
fn record(bytes: usize) {
    let _ = ALLOCS.try_with(|cell| {
        if let Some((n, b)) = cell.get() {
            cell.set(Some((n + 1, b + bytes as u64)));
        }
    });
}
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        record(l.size());
        System.alloc(l)
    }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
        record(l.size());
        System.alloc_zeroed(l)
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {
        record(n);
        System.realloc(p, l, n)
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        System.dealloc(p, l)
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;
fn measured<T>(f: impl FnOnce() -> T) -> (T, f64, usize, u64) {
    ALLOCS.with(|cell| cell.set(Some((0, 0))));
    let start = Instant::now();
    let result = f();
    let ms = start.elapsed().as_secs_f64() * 1000.;
    let (allocations, bytes) = ALLOCS.with(|cell| cell.replace(None).unwrap());
    (result, ms, allocations, bytes)
}
fn main() {
    let files = BTreeMap::from([("App.ui".to_owned(), "component App { state items: List = []; Column { width:260; height:4096; for item in state.items key item.id { TextInput { width:200; height:32; value <-> item.title; } } } }".to_owned())]);
    let mut results = Vec::new();
    for count in [8usize, 32, 96] {
        let items = (0..count)
            .map(|i| {
                Value::Object(BTreeMap::from([
                    ("id".to_owned(), Value::Text(format!("id{i}"))),
                    ("title".to_owned(), Value::Text(format!("title{i}"))),
                ]))
            })
            .collect();
        let state = Properties::from([("items".to_owned(), Value::List(items))]);
        let mut doc = Document::from_ui_files(&files, "App.ui", &state).unwrap();
        let (source, templates, _) = doc.render_scene().unwrap();
        let mut runtime = Runtime::from_sources(&source, &templates).unwrap();
        assert_eq!(doc.sync_runtime_bindings(&runtime, None).unwrap(), 0);
        let mut noop = Vec::new();
        let mut edit = Vec::new();
        let mut noop_alloc = Vec::new();
        let mut edit_alloc = Vec::new();
        for sample in 0..7 {
            let (changed, ms, n, bytes) =
                measured(|| doc.sync_runtime_bindings(&runtime, None).unwrap());
            assert_eq!(changed, 0);
            noop.push(ms);
            noop_alloc.push((n, bytes));
            runtime
                .set_binding_value(0, &format!("edited{sample}"), true)
                .unwrap();
            let (changed, ms, n, bytes) =
                measured(|| doc.sync_runtime_bindings(&runtime, None).unwrap());
            assert_eq!(changed, 1);
            edit.push(ms);
            edit_alloc.push((n, bytes));
            let Value::List(items) = &doc.states[0]["items"] else {
                panic!("items");
            };
            let Value::Object(first) = &items[0] else {
                panic!("item");
            };
            assert_eq!(first["title"], Value::Text(format!("edited{sample}")));
        }
        results.push(serde_json::json!({"controls":count,"noop_ms":noop,"one_edit_ms":edit,"noop_allocation_count_and_bytes":noop_alloc,"edit_allocation_count_and_bytes":edit_alloc}));
    }
    println!(
        "{}",
        serde_json::json!({"workload":"public Document::sync_runtime_bindings, 7 alternating noop/edit samples", "results":results})
    );
}
