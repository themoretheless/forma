//! Public retained-document binding workload; prints raw timings as JSON.
use forma::{form_document::{Document, Properties, Value}, Runtime};
use std::{collections::BTreeMap, time::Instant};
fn main() {
    let files = BTreeMap::from([("App.ui".to_owned(), "component App { state items: List = []; Column { width:260; height:4096; for item in state.items key item.id { TextInput { width:200; height:32; value <-> item.title; } } } }".to_owned())]);
    let mut results = Vec::new();
    for count in [8usize, 32, 96] {
        let items = (0..count).map(|i| Value::Object(BTreeMap::from([
            ("id".to_owned(), Value::Text(format!("id{i}"))),
            ("title".to_owned(), Value::Text(format!("title{i}"))),
        ]))).collect();
        let state = Properties::from([("items".to_owned(), Value::List(items))]);
        let mut doc = Document::from_ui_files(&files, "App.ui", &state).unwrap();
        let (source, templates, _) = doc.render_scene().unwrap();
        let mut runtime = Runtime::from_sources(&source, &templates).unwrap();
        assert_eq!(doc.sync_runtime_bindings(&runtime, None).unwrap(), 0);
        let mut noop = Vec::new();
        let mut edit = Vec::new();
        for sample in 0..7 {
            let start = Instant::now();
            assert_eq!(doc.sync_runtime_bindings(&runtime, None).unwrap(), 0);
            noop.push(start.elapsed().as_secs_f64() * 1000.);
            runtime.set_binding_value(0, &format!("edited{sample}"), true).unwrap();
            let start = Instant::now();
            assert_eq!(doc.sync_runtime_bindings(&runtime, None).unwrap(), 1);
            edit.push(start.elapsed().as_secs_f64() * 1000.);
            let Value::List(items) = &doc.states[0]["items"] else { panic!("items"); };
            let Value::Object(first) = &items[0] else { panic!("item"); };
            assert_eq!(first["title"], Value::Text(format!("edited{sample}")));
        }
        results.push(serde_json::json!({"controls":count,"noop_ms":noop,"one_edit_ms":edit}));
    }
    println!("{}", serde_json::json!({"workload":"public Document::sync_runtime_bindings, 7 alternating noop/edit samples", "results":results}));
}
