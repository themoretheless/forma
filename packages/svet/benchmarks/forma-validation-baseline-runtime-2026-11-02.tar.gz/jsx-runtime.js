import { Fragment, h } from "./dom.js";
import {} from "./reactivity.js";
export { Fragment };
export function jsx(type, props, key) {
    const finalProps = props ? { ...props } : {};
    if (key !== undefined) {
        finalProps.key = key;
    }
    const children = finalProps.children;
    delete finalProps.children;
    if (children !== undefined) {
        return h(type, finalProps, ...(Array.isArray(children) ? children : [children]));
    }
    return h(type, finalProps);
}
export const jsxs = jsx;
export const jsxDEV = jsx;
//# sourceMappingURL=jsx-runtime.js.map