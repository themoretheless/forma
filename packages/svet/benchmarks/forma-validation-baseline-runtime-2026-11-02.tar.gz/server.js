/** Node host for the shared SSR runtime. Import from svet-engine/server. */
import { AsyncLocalStorage } from 'node:async_hooks';
import { randomUUID } from 'node:crypto';
import { createSsrRuntime } from "./ssr-runtime.js";
const host = { createAsyncContext: () => new AsyncLocalStorage(), randomUUID };
const runtime = createSsrRuntime(host);
export const { runWithIsolatedContextAsync, runWithOwnerScopeAsync, renderToStringAsync, renderToChunksAsync, renderToReadableStreamAsync } = runtime;
export { SsrTimeoutError } from "./ssr-runtime.js";
//# sourceMappingURL=server.js.map