/**
 * # Svet Engine — Public API (`src/engine/index.ts`)
 *
 * Complete Hybrid TypeScript + Rust WebAssembly UI Framework.
 */
export { signal, computed, effect, ReactiveStabilizationError, ReactiveCycleError, batch, untrack, createRoot, onCleanup, getCurrentOwner, captureReactiveContext, ReactiveContextDisposedError, runWithOwnerScope, lookupOwnerContext, runWithIsolatedContext, createStore, createDeepStore, flushEffects, resetReactiveSystem, getGraphTelemetry, } from "./reactivity.js";
export { h, Fragment, Show, For, mount, bindProp, insertChild, getDomMutationCount, resetDomMutationCount, } from "./dom.js";
export { createContext, useContext, Portal, createResource, Suspense, ErrorBoundary, createRouter, useRouter, RouterView, Link, } from "./advanced.js";
export { serializeState, resumeContainer, disposeResumedContainer, renderToString, serializeDomNodeToHtml, createServerAction, ServerActionDisposedError, } from "./resumable.js";
export { computeLisWasm, getWasmCore, createWasmCoreInstance, installSvetWasmModule, withWasmCore, } from "./wasm-bridge.js";
export { transformSvetJsx, transformSvetJsxWithMap, SvetJsxCompileError, svetVitePlugin } from "./compiler.js";
export { configureGpuSubsystem, initWebGpuHardware, resetGpuTelemetry, createGpuTensor, syncGpuArena, executeGpuVectorFma, dispatchGpuComputeKernel, dispatchGpuComputeKernelAsync, getGpuTelemetry, GpuComputeCapacityError, createTransform3D, createPerspectiveCamera3D, createMesh3D, createCubeMesh3D, pickNearestVertex3D, Canvas3D, Viewport3D, GpuSparkline, } from "./gpu.js";
export { createFormaProperty, createFormaContext, formaStdlib, transformFormaPipes, evaluateFormaExpression, doesFormaPatternMatch, compileFormaComponent, compileFormaAst, parseFormaSource, registerFormaComponent, validateFormaSource, compileFormaToJsModule, createSpring, flushSpringFrame, createPersistedSignal, createForm, createContractForm, FormaHost, } from "./forma.js";
export { createTimeTravelDebugger, VirtualList, } from "./devtools.js";
export { dispatchGpuComputeResident, readGpuResidentTensor, readGpuResidentSnapshot, GpuResidentCapacityError } from "./gpu-resident.js";
export { createSsrStreamReceiver, SSR_STREAM_VERSION } from "./stream.js";
export { SSR_STREAM_ACCEPT_HEADER, SSR_STREAM_VERSION_HEADER, SSR_STREAM_CONTENT_TYPE, negotiateSsrStreamVersion, assertSsrStreamResponse } from "./stream-protocol.js";
export { SSR_STREAM_HTML_REFERENCE_CODEC, createSsrStreamTransportEncoder, createSsrStreamTransportDecoder } from "./stream-codec.js";
export { SSR_STREAM_CODEC_HEADER, negotiateSsrStreamCodec } from "./stream-protocol.js";
//# sourceMappingURL=index.js.map