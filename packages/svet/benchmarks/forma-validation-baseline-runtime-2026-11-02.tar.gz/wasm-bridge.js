/**
 * # Svet WASM Bridge (`wasm-bridge.ts`)
 *
 * Connects TypeScript directly to the compiled Rust WebAssembly reactive core (`svet-wasm`).
 * - Synchronous instantiation so zero `async/await` ceremony is required at app boot.
 * - Supports isolated WASM instances (`createWasmCoreInstance` / `runInSsrContext`) so concurrent
 *   SSR requests never share global graph state!
 * - Zero-copy `Uint32Array` views directly into WASM linear memory for batch effect flushing
 *   and O(n log n) Longest Increasing Subsequence (LIS) reconciliation.
 */
import { decodeWasmBinary, WASM_EXPORTS } from "./wasm-binary.js";
export const KIND_SIGNAL = 0;
export const KIND_COMPUTED = 1;
export const KIND_EFFECT = 2;
export const STATE_CLEAN = 0;
export const STATE_CHECK = 1;
export const STATE_DIRTY = 2;
export const STATE_DISPOSED = 255;
let compiledModule = null;
let defaultCore = null;
// Explicit synchronous scopes select one native core across compatible copies.
// Only live calls are stored; async continuations use their host carrier again.
const coreOverrideHost = globalThis;
const coreOverrides = coreOverrideHost[Symbol.for('svet.wasm-core.overrides.v1')] ??= [];
let asyncCoreResolver;
let escapeAsyncContext;
/** Keep long-lived device event subscriptions outside a request's async store. */
export function withoutAsyncCoreContext(callback) {
    return escapeAsyncContext ? escapeAsyncContext(callback) : callback();
}
/** Internal adapter hook; the browser entry has no Node dependency. */
export function installAsyncCoreResolver(resolver, escape) {
    asyncCoreResolver = resolver;
    escapeAsyncContext = escape;
}
/** Install this package's precompiled asset before any core is created. */
export function installSvetWasmModule(module) {
    if (!(module instanceof WebAssembly.Module))
        throw TypeError('Expected a precompiled Svet WebAssembly.Module');
    if (compiledModule) {
        if (compiledModule === module)
            return;
        throw Error('Svet WASM module is already initialized');
    }
    const actual = WebAssembly.Module.exports(module).sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
    if (WebAssembly.Module.imports(module).length || JSON.stringify(actual) !== JSON.stringify(WASM_EXPORTS))
        throw TypeError('Incompatible Svet WASM export shape');
    compiledModule = module;
}
function getCompiledModule() {
    if (!compiledModule) {
        const bytes = decodeWasmBinary();
        compiledModule = new WebAssembly.Module(bytes);
    }
    return compiledModule;
}
/**
 * Creates a brand-new isolated WebAssembly instance of the Svet reactive engine.
 * Ideal for concurrent SSR requests or multi-tenant sandboxes.
 */
export function createWasmCoreInstance() {
    const instance = new WebAssembly.Instance(getCompiledModule(), {});
    return instance.exports;
}
/**
 * Returns the currently active WASM core (either the isolated SSR context or the default singleton).
 */
export function getWasmCore() {
    const activeCore = coreOverrides.length ? coreOverrides[coreOverrides.length - 1] : undefined;
    if (activeCore)
        return activeCore;
    const requestCore = asyncCoreResolver?.();
    if (requestCore)
        return requestCore;
    if (!defaultCore) {
        defaultCore = createWasmCoreInstance();
    }
    return defaultCore;
}
/**
 * Temporarily switches the active WASM core to `customCore` for the duration of `fn`.
 */
export function withWasmCore(customCore, fn) {
    coreOverrides.push(customCore);
    try {
        return fn();
    }
    finally {
        coreOverrides.pop();
    }
}
const EMPTY_U32 = new Uint32Array(0);
/**
 * Reads the flushed effect IDs directly from WASM linear memory without per-item FFI calls.
 */
export function readFlushedEffects(core) {
    const count = core.svet_prepare_flush();
    if (count === 0) {
        return EMPTY_U32;
    }
    const ptr = core.svet_get_flush_ptr();
    return new Uint32Array(core.memory.buffer, ptr, count);
}
/**
 * Computes the Longest Increasing Subsequence (LIS) in WASM linear memory in O(n log n) time.
 * Ignore marker: `0xFFFFFFFF` (`u32::MAX`) represents newly inserted items.
 */
export function computeLisWasm(indices) {
    const core = getWasmCore();
    const len = indices.length;
    if (len === 0)
        return EMPTY_U32;
    const inPtr = core.svet_prepare_lis_input(len);
    const wasmInput = new Uint32Array(core.memory.buffer, inPtr, len);
    wasmInput.set(indices);
    const lisLen = core.svet_compute_lis_buffered(len);
    if (lisLen === 0)
        return EMPTY_U32;
    const outPtr = core.svet_get_lis_ptr();
    return new Uint32Array(core.memory.buffer, outPtr, lisLen);
}
//# sourceMappingURL=wasm-bridge.js.map