/** Internal typed bridge; GPU rendering does not import the compute executor. */
import { getReactiveGeneration, isOwnerScopeDisposed } from "./reactivity.js";
export const residentRecords = new WeakMap();
export function assertResidentRecord(record) {
    if (record.disposed || isOwnerScopeDisposed(record.owner))
        throw new Error('GPU resident result disposed');
    if (record.generation !== getReactiveGeneration(record.core))
        throw new Error('GPU resident context reset');
}
export function residentVertexRecord(handle, core, device, vertexCount) {
    const record = residentRecords.get(handle);
    if (!record)
        throw new TypeError('Invalid GPU resident vertices');
    assertResidentRecord(record);
    if (record.core !== core || record.device !== device)
        throw new Error('Resident vertices belong to another context or device');
    if (record.bytes !== vertexCount * 16)
        throw new RangeError('Resident vertices must contain one clip-space float4 per mesh vertex');
    return record;
}
export function snapshotResidentVertices(input, signal) {
    const record = residentRecords.get(input);
    if (!record)
        return Promise.reject(new TypeError('Invalid GPU resident result'));
    return record.readSnapshot(input, { signal });
}
//# sourceMappingURL=gpu-resident-bridge.js.map