//! Public retained-document binding workload; prints raw timings as JSON.
use forma::{
    form_document::{Document, Properties, Value},
    Runtime,
};
use std::{
    alloc::{GlobalAlloc, Layout, System},
    cell::Cell,
};
use std::{collections::BTreeMap, time::Instant};
struct Counting;
thread_local! { static ALLOCS: Cell<Option<(usize, u64)>> = const { Cell::new(None) }; }
fn record(bytes: usize) {
    let _ = ALLOCS.try_with(|cell| {
        if let Some((n, b)) = cell.get() {
            cell.set(Some((n + 1, b + bytes as u64)));
        }
    });
}
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        record(l.size());
        System.alloc(l)
    }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
        record(l.size());
        System.alloc_zeroed(l)
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {
        record(n);
        System.realloc(p, l, n)
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        System.dealloc(p, l)
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;
fn measured<T>(f: impl FnOnce() -> T) -> (T, f64, usize, u64) {
    ALLOCS.with(|cell| cell.set(Some((0, 0))));
    let start = Instant::now();
    let result = f();
    let ms = start.elapsed().as_secs_f64() * 1000.;
    let (allocations, bytes) = ALLOCS.with(|cell| cell.replace(None).unwrap());
    (result, ms, allocations, bytes)
}
fn main() {
    if std::env::args().any(|arg| arg == "--retained") {
        retained();
        return;
    }
    let files = BTreeMap::from([("App.ui".to_owned(), "component App { state items: List = []; Column { width:260; height:4096; for item in state.items key item.id { TextInput { width:200; height:32; value <-> item.title; } } } }".to_owned())]);
    let mut results = Vec::new();
    for count in [8usize, 32, 96] {
        let items = (0..count)
            .map(|i| {
                Value::Object(BTreeMap::from([
                    ("id".to_owned(), Value::Text(format!("id{i}"))),
                    ("title".to_owned(), Value::Text(format!("title{i}"))),
                ]))
            })
            .collect();
        let state = Properties::from([("items".to_owned(), Value::List(items))]);
        let mut doc = Document::from_ui_files(&files, "App.ui", &state).unwrap();
        let (source, templates, _) = doc.render_scene().unwrap();
        let mut runtime = Runtime::from_sources(&source, &templates).unwrap();
        assert_eq!(doc.sync_runtime_bindings(&runtime, None).unwrap(), 0);
        let mut noop = Vec::new();
        let mut edit = Vec::new();
        let mut noop_alloc = Vec::new();
        let mut edit_alloc = Vec::new();
        let mut render_ms = Vec::new();
        let mut render_alloc = Vec::new();
        for sample in 0..7 {
            let (_, ms, n, bytes) = measured(|| {
                let (_, _, controls) = doc.render_scene().unwrap();
                assert_eq!(controls.len(), count);
            });
            render_ms.push(ms);
            render_alloc.push((n, bytes));
            let (changed, ms, n, bytes) =
                measured(|| doc.sync_runtime_bindings(&runtime, None).unwrap());
            assert_eq!(changed, 0);
            noop.push(ms);
            noop_alloc.push((n, bytes));
            runtime
                .set_binding_value(0, &format!("edited{sample}"), true)
                .unwrap();
            let (changed, ms, n, bytes) =
                measured(|| doc.sync_runtime_bindings(&runtime, None).unwrap());
            assert_eq!(changed, 1);
            edit.push(ms);
            edit_alloc.push((n, bytes));
            let Value::List(items) = &doc.states[0]["items"] else {
                panic!("items");
            };
            let Value::Object(first) = &items[0] else {
                panic!("item");
            };
            assert_eq!(first["title"], Value::Text(format!("edited{sample}")));
        }
        results.push(serde_json::json!({"controls":count,"noop_ms":noop,"one_edit_ms":edit,"noop_allocation_count_and_bytes":noop_alloc,"edit_allocation_count_and_bytes":edit_alloc,"render_scene_ms":render_ms,"render_scene_allocation_count_and_bytes":render_alloc}));
    }
    println!(
        "{}",
        serde_json::json!({"workload":"public Document::sync_runtime_bindings, 7 alternating noop/edit samples", "results":results})
    );
}

fn retained() {
    let files = BTreeMap::from([("App.ui".to_owned(), "component App { state items: List = []; Column { width:260; height:16384; for item in state.items key item.id { TextInput { width:200; height:32; value <-> item.title; } } } }".to_owned())]);
    let mut results = Vec::new();
    for svet in [false, true] {
        for count in [8usize, 32, 96, 256] {
            let items = (0..count).map(|i| Value::Object(Properties::from([
                ("id".into(), Value::Text(format!("id{i}"))),
                ("title".into(), Value::Text(format!("title{i}"))),
            ]))).collect();
            let state = Properties::from([("items".into(), Value::List(items))]);
            let mut runtime = Runtime::from_ui_files(&files, "App.ui", &state).unwrap();
            runtime.set_svet_document_scheduling(svet);
            assert_eq!(runtime.control_count(), count);
            assert!(!runtime.sync_ui_bindings_native().unwrap());
            let mut samples = Vec::new();
            for sample in 0..7 {
                let (rebuilt, idle_ms, idle_count, idle_bytes) = measured(|| runtime.sync_ui_bindings_native().unwrap());
                assert!(!rebuilt);
                let value = format!("edited{sample}");
                runtime.set_binding_value(0, &value, true).unwrap();
                let (rebuilt, edit_ms, edit_count, edit_bytes) = measured(|| runtime.sync_ui_bindings_native().unwrap());
                assert!(rebuilt);
                assert_eq!(runtime.text_value(0), value);
                let state = runtime.ui_state_properties();
                let Value::List(items) = &state["items"] else { panic!("items") };
                let Value::Object(first) = &items[0] else { panic!("item") };
                assert_eq!(first["title"], Value::Text(value));
                assert_eq!(items.len(), count);
                if svet {
                    let telemetry = runtime.svet_document_telemetry().unwrap();
                    assert_eq!(telemetry.batch_depth, 0);
                    assert_eq!(telemetry.tracking_depth, 0);
                }
                samples.push(serde_json::json!({"idle_ms":idle_ms,"idle_allocations":idle_count,"idle_requested_bytes":idle_bytes,"edit_ms":edit_ms,"edit_allocations":edit_count,"edit_requested_bytes":edit_bytes}));
            }
            results.push(serde_json::json!({"svet":svet,"controls":count,"samples":samples}));
        }
    }
    println!("{}", serde_json::json!({"workload":"retained Runtime sync, 7 alternating idle/edit samples; edit includes scene rendering and Runtime replacement, excludes painting/presentation", "results":results}));
}
