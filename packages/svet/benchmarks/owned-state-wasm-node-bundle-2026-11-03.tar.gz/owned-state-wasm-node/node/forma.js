/* @ts-self-types="./forma.d.ts" */

class Button {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ButtonFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_button_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    action() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.button_action(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    activate() {
        wasm.button_activate(this.__wbg_ptr);
    }
    /**
     * @returns {string}
     */
    background_color() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.button_background_color(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Float32Array}
     */
    bounds() {
        const ret = wasm.button_bounds(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    clicks() {
        const ret = wasm.button_clicks(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {boolean}
     */
    clipped() {
        const ret = wasm.button_clipped(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Studio paints its rounded artboard background separately from children.
     * This avoids clipping overflowing children just to round the background.
     * @param {number} width
     * @param {number} height
     * @param {number} scale
     * @returns {Uint8Array}
     */
    content_pixels(width, height, scale) {
        const ret = wasm.button_content_pixels(this.__wbg_ptr, width, height, scale);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {boolean}
     */
    disabled() {
        const ret = wasm.button_disabled(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {boolean} focused
     */
    focus(focused) {
        wasm.button_focus(this.__wbg_ptr, focused);
    }
    /**
     * @returns {number}
     */
    frame_radius() {
        const ret = wasm.button_frame_radius(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} scale
     * @param {boolean} background
     * @returns {Float32Array}
     */
    gpu_commands(scale, background) {
        const ret = wasm.button_gpu_commands(this.__wbg_ptr, scale, background);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} scale
     * @param {boolean} background
     * @returns {Float32Array}
     */
    gpu_edges(scale, background) {
        const ret = wasm.button_gpu_edges(this.__wbg_ptr, scale, background);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {Float32Array}
     */
    gpu_paints() {
        const ret = wasm.button_gpu_paints(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} width
     * @param {number} height
     * @param {number} scale
     * @param {boolean} opaque
     * @returns {Float32Array}
     */
    gpu_params(width, height, scale, opaque) {
        const ret = wasm.button_gpu_params(this.__wbg_ptr, width, height, scale, opaque);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} width
     * @param {number} height
     * @param {number} scale
     * @param {boolean} background
     * @returns {Uint32Array}
     */
    gpu_tiles(width, height, scale, background) {
        const ret = wasm.button_gpu_tiles(this.__wbg_ptr, width, height, scale, background);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    height() {
        const ret = wasm.button_height(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} x
     * @param {number} y
     * @returns {boolean}
     */
    hit(x, y) {
        const ret = wasm.button_hit(this.__wbg_ptr, x, y);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    is_animating() {
        const ret = wasm.button_is_animating(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    is_focused() {
        const ret = wasm.button_is_focused(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {string}
     */
    key() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.button_key(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Shared web/native keyboard gesture: 1 = Space, 2 = Enter.
     * Repeats and unmatched releases cannot activate; blur cancels the gesture.
     * @param {number} key
     * @param {boolean} pressed
     * @param {boolean} repeat
     */
    key_event(key, pressed, repeat) {
        wasm.button_key_event(this.__wbg_ptr, key, pressed, repeat);
    }
    /**
     * @returns {string}
     */
    label() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.button_label(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} source
     */
    load(source) {
        const ptr0 = passStringToWasm0(source, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.button_load(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} source
     * @param {string} component
     */
    load_component(source, component) {
        const ptr0 = passStringToWasm0(source, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(component, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.button_load_component(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    constructor() {
        const ret = wasm.button_new();
        this.__wbg_ptr = ret;
        ButtonFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string}
     */
    overflow() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.button_overflow(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} width
     * @param {number} height
     * @param {number} scale
     * @returns {Uint8Array}
     */
    pixels(width, height, scale) {
        const ret = wasm.button_pixels(this.__wbg_ptr, width, height, scale);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} kind
     */
    pointer(x, y, kind) {
        wasm.button_pointer(this.__wbg_ptr, x, y, kind);
    }
    /**
     * @param {Button} previous
     */
    preserve_interaction(previous) {
        _assertClass(previous, Button);
        wasm.button_preserve_interaction(this.__wbg_ptr, previous.__wbg_ptr);
    }
    /**
     * @returns {Uint32Array}
     */
    raster_stats() {
        const ret = wasm.button_raster_stats(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    release_cpu_cache() {
        wasm.button_release_cpu_cache(this.__wbg_ptr);
    }
    /**
     * @returns {number}
     */
    render_height() {
        const ret = wasm.button_render_height(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    render_width() {
        const ret = wasm.button_render_width(this.__wbg_ptr);
        return ret;
    }
    /**
     * Proximity only: does not change hover, focus, pointer capture or actions.
     * @param {number} x
     * @param {number} y
     * @param {boolean} present
     */
    reveal_pointer(x, y, present) {
        wasm.button_reveal_pointer(this.__wbg_ptr, x, y, present);
    }
    /**
     * @param {number} dx
     * @param {number} dy
     */
    scroll(dx, dy) {
        wasm.button_scroll(this.__wbg_ptr, dx, dy);
    }
    /**
     * @returns {Float32Array}
     */
    scroll_offset() {
        const ret = wasm.button_scroll_offset(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {boolean}
     */
    scrollable() {
        const ret = wasm.button_scrollable(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {boolean} reduced
     */
    set_reduced_motion(reduced) {
        wasm.button_set_reduced_motion(this.__wbg_ptr, reduced);
    }
    /**
     * @param {number} delta_ms
     * @returns {boolean}
     */
    tick(delta_ms) {
        const ret = wasm.button_tick(this.__wbg_ptr, delta_ms);
        return ret !== 0;
    }
    /**
     * @returns {Float32Array}
     */
    viewport() {
        const ret = wasm.button_viewport(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    visual_revision() {
        const ret = wasm.button_visual_revision(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    width() {
        const ret = wasm.button_width(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) Button.prototype[Symbol.dispose] = Button.prototype.free;
exports.Button = Button;

class CheckValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CheckValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_checkvalue_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    activate() {
        const ret = wasm.checkvalue_activate(this.__wbg_ptr);
        return ret;
    }
    /**
     * State: 0 = unchecked, 1 = checked, 2 = mixed.
     * @param {number} initial
     * @param {boolean} tristate
     */
    constructor(initial, tristate) {
        const ret = wasm.checkvalue_new(initial, tristate);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        CheckValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {number}
     */
    state() {
        const ret = wasm.checkvalue_state(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) CheckValue.prototype[Symbol.dispose] = CheckValue.prototype.free;
exports.CheckValue = CheckValue;

class CodeEditorValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CodeEditorValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_codeeditorvalue_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    cursor_column() {
        const ret = wasm.codeeditorvalue_cursor_column(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    cursor_line() {
        const ret = wasm.codeeditorvalue_cursor_line(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {boolean}
     */
    indent() {
        const ret = wasm.codeeditorvalue_indent(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    line_count() {
        const ret = wasm.codeeditorvalue_line_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {string} initial
     * @param {number} tab_size
     */
    constructor(initial, tab_size) {
        const ptr0 = passStringToWasm0(initial, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.codeeditorvalue_new(ptr0, len0, tab_size);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        CodeEditorValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {number}
     */
    token_count() {
        const ret = wasm.codeeditorvalue_token_count(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * @returns {string}
     */
    value() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.codeeditorvalue_value(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) CodeEditorValue.prototype[Symbol.dispose] = CodeEditorValue.prototype.free;
exports.CodeEditorValue = CodeEditorValue;

class CommandPaletteValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CommandPaletteValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_commandpalettevalue_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    active_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.commandpalettevalue_active_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Uint32Array}
     */
    filtered() {
        const ret = wasm.commandpalettevalue_filtered(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} delta
     * @returns {string}
     */
    move_selection(delta) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.commandpalettevalue_move_selection(this.__wbg_ptr, delta);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string[]} titles
     */
    constructor(titles) {
        const ptr0 = passArrayJsValueToWasm0(titles, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.commandpalettevalue_new(ptr0, len0);
        this.__wbg_ptr = ret;
        CommandPaletteValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {string} query
     */
    set_query(query) {
        const ptr0 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.commandpalettevalue_set_query(this.__wbg_ptr, ptr0, len0);
    }
}
if (Symbol.dispose) CommandPaletteValue.prototype[Symbol.dispose] = CommandPaletteValue.prototype.free;
exports.CommandPaletteValue = CommandPaletteValue;

class DataTableValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DataTableValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_datatablevalue_free(ptr, 0);
    }
    /**
     * @param {number} delta
     * @returns {number}
     */
    move_selection(delta) {
        const ret = wasm.datatablevalue_move_selection(this.__wbg_ptr, delta);
        return ret;
    }
    /**
     * @param {Float64Array} column_widths
     * @param {number} row_count
     * @param {number} row_height
     * @param {number} viewport_height
     */
    constructor(column_widths, row_count, row_height, viewport_height) {
        const ptr0 = passArrayF64ToWasm0(column_widths, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.datatablevalue_new(ptr0, len0, row_count, row_height, viewport_height);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        DataTableValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} column
     * @param {number} width
     * @returns {number}
     */
    resize_column(column, width) {
        const ret = wasm.datatablevalue_resize_column(this.__wbg_ptr, column, width);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {number} row
     * @param {boolean} additive
     */
    select_row(row, additive) {
        const ret = wasm.datatablevalue_select_row(this.__wbg_ptr, row, additive);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} filter
     */
    set_filter(filter) {
        const ptr0 = passStringToWasm0(filter, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.datatablevalue_set_filter(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number} scroll_y
     * @returns {number}
     */
    set_scroll_y(scroll_y) {
        const ret = wasm.datatablevalue_set_scroll_y(this.__wbg_ptr, scroll_y);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {number} column
     * @returns {number}
     */
    toggle_sort(column) {
        const ret = wasm.datatablevalue_toggle_sort(this.__wbg_ptr, column);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {number} overscan
     * @returns {Uint32Array}
     */
    virtual_window(overscan) {
        const ret = wasm.datatablevalue_virtual_window(this.__wbg_ptr, overscan);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) DataTableValue.prototype[Symbol.dispose] = DataTableValue.prototype.free;
exports.DataTableValue = DataTableValue;

class DateTimeValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DateTimeValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_datetimevalue_free(ptr, 0);
    }
    /**
     * @returns {Uint8Array}
     */
    calendar_grid() {
        const ret = wasm.datetimevalue_calendar_grid(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {string}
     */
    format_date() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.datetimevalue_format_date(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    format_iso() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.datetimevalue_format_iso(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} year
     * @param {number} month
     * @param {number} day
     * @param {number} hour
     * @param {number} minute
     */
    constructor(year, month, day, hour, minute) {
        const ret = wasm.datetimevalue_new(year, month, day, hour, minute);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        DateTimeValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} delta
     * @returns {string}
     */
    step_days(delta) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.datetimevalue_step_days(this.__wbg_ptr, delta);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} delta
     * @returns {string}
     */
    step_months(delta) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.datetimevalue_step_months(this.__wbg_ptr, delta);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) DateTimeValue.prototype[Symbol.dispose] = DateTimeValue.prototype.free;
exports.DateTimeValue = DateTimeValue;

class RangeValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RangeValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_rangevalue_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    fraction() {
        const ret = wasm.rangevalue_fraction(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} min
     * @param {number} max
     * @param {number} step
     * @param {number} value
     */
    constructor(min, max, step, value) {
        const ret = wasm.rangevalue_new(min, max, step, value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        RangeValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} value
     * @returns {number}
     */
    set(value) {
        const ret = wasm.rangevalue_set(this.__wbg_ptr, value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {number} fraction
     * @returns {number}
     */
    set_fraction(fraction) {
        const ret = wasm.rangevalue_set_fraction(this.__wbg_ptr, fraction);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {number} steps
     * @returns {number}
     */
    step_by(steps) {
        const ret = wasm.rangevalue_step_by(this.__wbg_ptr, steps);
        return ret;
    }
    /**
     * @returns {number}
     */
    value() {
        const ret = wasm.rangevalue_value(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) RangeValue.prototype[Symbol.dispose] = RangeValue.prototype.free;
exports.RangeValue = RangeValue;

class RichTextValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RichTextValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_richtextvalue_free(ptr, 0);
    }
    clear_formatting() {
        wasm.richtextvalue_clear_formatting(this.__wbg_ptr);
    }
    /**
     * @returns {number}
     */
    heading_level() {
        const ret = wasm.richtextvalue_heading_level(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {string} markdown
     */
    constructor(markdown) {
        const ptr0 = passStringToWasm0(markdown, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.richtextvalue_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        RichTextValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} level
     */
    set_heading_level(level) {
        wasm.richtextvalue_set_heading_level(this.__wbg_ptr, level);
    }
    /**
     * @returns {string}
     */
    text() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.richtextvalue_text(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    to_markdown() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.richtextvalue_to_markdown(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {boolean}
     */
    toggle_bold() {
        const ret = wasm.richtextvalue_toggle_bold(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    toggle_code() {
        const ret = wasm.richtextvalue_toggle_code(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    toggle_italic() {
        const ret = wasm.richtextvalue_toggle_italic(this.__wbg_ptr);
        return ret !== 0;
    }
}
if (Symbol.dispose) RichTextValue.prototype[Symbol.dispose] = RichTextValue.prototype.free;
exports.RichTextValue = RichTextValue;

class Runtime {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RuntimeFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_runtime_free(ptr, 0);
    }
    /**
     * Exports the AccessKit-compatible semantic accessibility tree as a compact JSON snapshot.
     * @returns {string}
     */
    accessibility_tree_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_accessibility_tree_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    action() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_action(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    activate() {
        wasm.runtime_activate(this.__wbg_ptr);
    }
    /**
     * @param {number} i
     */
    activate_control(i) {
        wasm.runtime_activate_control(this.__wbg_ptr, i);
    }
    /**
     * @returns {number}
     */
    active_modal() {
        const ret = wasm.runtime_active_modal(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string}
     */
    background_color() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_background_color(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Float32Array}
     */
    bounds() {
        const ret = wasm.runtime_bounds(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Explicitly discard buffered activations, clearing an overflow refusal.
     * Widget values remain available for the next binding synchronization.
     * @returns {number}
     */
    cancel_ui_binding_activations() {
        const ret = wasm.runtime_cancel_ui_binding_activations(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    clicks() {
        const ret = wasm.runtime_clicks(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {boolean}
     */
    clipped() {
        const ret = wasm.runtime_clipped(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {number} m
     * @returns {boolean}
     */
    close_modal(m) {
        const ret = wasm.runtime_close_modal(this.__wbg_ptr, m);
        return ret !== 0;
    }
    /**
     * Compile a UI project to a versioned transport in Rust for a later runtime load.
     * @param {string} files_json
     * @param {string} entry_file
     * @param {string} state_json
     * @returns {string}
     */
    static compile_ui_scene_artifact(files_json, entry_file, state_json) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(files_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(entry_file, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(state_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.runtime_compile_ui_scene_artifact(ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * @param {number} w
     * @param {number} h
     * @param {number} s
     * @returns {Uint8Array}
     */
    content_pixels(w, h, s) {
        const ret = wasm.runtime_content_pixels(this.__wbg_ptr, w, h, s);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @param {number} i
     * @returns {string}
     */
    control_action(i) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_control_action(this.__wbg_ptr, i);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Hidden by a closed layer or covered by another layer's backdrop.
     * @param {number} i
     * @returns {boolean}
     */
    control_blocked(i) {
        const ret = wasm.runtime_control_blocked(this.__wbg_ptr, i);
        return ret !== 0;
    }
    /**
     * @param {number} i
     * @returns {Float32Array}
     */
    control_bounds(i) {
        const ret = wasm.runtime_control_bounds(this.__wbg_ptr, i);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} i
     * @returns {number}
     */
    control_clicks(i) {
        const ret = wasm.runtime_control_clicks(this.__wbg_ptr, i);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    control_count() {
        const ret = wasm.runtime_control_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} i
     * @returns {boolean}
     */
    control_disabled(i) {
        const ret = wasm.runtime_control_disabled(this.__wbg_ptr, i);
        return ret !== 0;
    }
    /**
     * @param {number} i
     * @returns {boolean}
     */
    control_editable(i) {
        const ret = wasm.runtime_control_editable(this.__wbg_ptr, i);
        return ret !== 0;
    }
    /**
     * @param {number} i
     * @returns {boolean}
     */
    control_focused(i) {
        const ret = wasm.runtime_control_focused(this.__wbg_ptr, i);
        return ret !== 0;
    }
    /**
     * @param {number} i
     * @returns {boolean}
     */
    control_hovered(i) {
        const ret = wasm.runtime_control_hovered(this.__wbg_ptr, i);
        return ret !== 0;
    }
    /**
     * @param {number} i
     * @returns {boolean}
     */
    control_interactive(i) {
        const ret = wasm.runtime_control_interactive(this.__wbg_ptr, i);
        return ret !== 0;
    }
    /**
     * @param {number} i
     * @returns {string}
     */
    control_key(i) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_control_key(this.__wbg_ptr, i);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} i
     * @returns {string}
     */
    control_label(i) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_control_label(this.__wbg_ptr, i);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Layer index of a control, -1 for the base scene.
     * @param {number} i
     * @returns {number}
     */
    control_modal(i) {
        const ret = wasm.runtime_control_modal(this.__wbg_ptr, i);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    disabled() {
        const ret = wasm.runtime_disabled(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    dismiss_count() {
        const ret = wasm.runtime_dismiss_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Escape or a press on the backdrop: closes the layer and records a
     * dismissal so hosts can run the layer's `dismissed` handler.
     * @param {number} m
     * @returns {boolean}
     */
    dismiss_modal(m) {
        const ret = wasm.runtime_dismiss_modal(this.__wbg_ptr, m);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    dismissed_index() {
        const ret = wasm.runtime_dismissed_index(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    event_index() {
        const ret = wasm.runtime_event_index(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {boolean} value
     */
    focus(value) {
        wasm.runtime_focus(this.__wbg_ptr, value);
    }
    /**
     * @param {number} index
     * @returns {boolean}
     */
    focus_control(index) {
        const ret = wasm.runtime_focus_control(this.__wbg_ptr, index);
        return ret !== 0;
    }
    /**
     * Move within the scene; false lets the browser transfer focus outside it.
     * @param {boolean} reverse
     * @returns {boolean}
     */
    focus_next(reverse) {
        const ret = wasm.runtime_focus_next(this.__wbg_ptr, reverse);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    focused_index() {
        const ret = wasm.runtime_focused_index(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    frame_radius() {
        const ret = wasm.runtime_frame_radius(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    geometry_revision() {
        const ret = wasm.runtime_geometry_revision(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} s
     * @param {boolean} b
     * @returns {Float32Array}
     */
    gpu_commands(s, b) {
        const ret = wasm.runtime_gpu_commands(this.__wbg_ptr, s, b);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} s
     * @param {boolean} b
     * @returns {Float32Array}
     */
    gpu_edges(s, b) {
        const ret = wasm.runtime_gpu_edges(this.__wbg_ptr, s, b);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {Float32Array}
     */
    gpu_paints() {
        const ret = wasm.runtime_gpu_paints(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} w
     * @param {number} h
     * @param {number} s
     * @param {boolean} o
     * @returns {Float32Array}
     */
    gpu_params(w, h, s, o) {
        const ret = wasm.runtime_gpu_params(this.__wbg_ptr, w, h, s, o);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} w
     * @param {number} h
     * @param {number} s
     * @param {boolean} b
     * @returns {Uint32Array}
     */
    gpu_tiles(w, h, s, b) {
        const ret = wasm.runtime_gpu_tiles(this.__wbg_ptr, w, h, s, b);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    height() {
        const ret = wasm.runtime_height(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} x
     * @param {number} y
     * @returns {boolean}
     */
    hit(x, y) {
        const ret = wasm.runtime_hit(this.__wbg_ptr, x, y);
        return ret !== 0;
    }
    /**
     * @param {number} x
     * @param {number} y
     * @returns {number}
     */
    hit_index(x, y) {
        const ret = wasm.runtime_hit_index(this.__wbg_ptr, x, y);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    is_animating() {
        const ret = wasm.runtime_is_animating(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    is_focused() {
        const ret = wasm.runtime_is_focused(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {string}
     */
    key() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_key(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Keys: 1 = Space, 2 = Enter, 3 = Escape. Escape dismisses the active
     * layer even while its text field is being edited.
     * @param {number} key
     * @param {boolean} pressed
     * @param {boolean} repeat
     */
    key_event(key, pressed, repeat) {
        wasm.runtime_key_event(this.__wbg_ptr, key, pressed, repeat);
    }
    /**
     * @returns {string}
     */
    label() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_label(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Control bounds change on scroll or source replacement. Paint and
     * text-content changes do not invalidate these bounds.
     * @returns {number}
     */
    layout_revision() {
        const ret = wasm.runtime_layout_revision(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {string} source
     */
    load(source) {
        const ptr0 = passStringToWasm0(source, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtime_load(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} source
     * @param {string} component
     */
    load_component(source, component) {
        const ptr0 = passStringToWasm0(source, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(component, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.runtime_load_component(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Load a complete artifact atomically through the Rust parser/runtime.
     * @param {string} json
     */
    load_scene_artifact(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtime_load_scene_artifact(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Compiles a JSON map of `.ui`/`.svg` project files directly in Rust and loads the rendered scene.
     * @param {string} files_json
     * @param {string} entry_file
     * @param {string} state_json
     */
    load_ui_files_json(files_json, entry_file, state_json) {
        const ptr0 = passStringToWasm0(files_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(entry_file, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(state_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.runtime_load_ui_files_json(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {number} m
     * @returns {string}
     */
    modal_action(m) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_modal_action(this.__wbg_ptr, m);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} m
     * @returns {Float32Array}
     */
    modal_bounds(m) {
        const ret = wasm.runtime_modal_bounds(this.__wbg_ptr, m);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    modal_count() {
        const ret = wasm.runtime_modal_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} m
     * @returns {boolean}
     */
    modal_dismissible(m) {
        const ret = wasm.runtime_modal_dismissible(this.__wbg_ptr, m);
        return ret !== 0;
    }
    /**
     * @param {number} m
     * @returns {boolean}
     */
    modal_is_open(m) {
        const ret = wasm.runtime_modal_is_open(this.__wbg_ptr, m);
        return ret !== 0;
    }
    /**
     * @param {number} m
     * @returns {string}
     */
    modal_key(m) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_modal_key(this.__wbg_ptr, m);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    constructor() {
        const ret = wasm.runtime_new();
        this.__wbg_ptr = ret;
        RuntimeFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} m
     * @returns {boolean}
     */
    open_modal(m) {
        const ret = wasm.runtime_open_modal(this.__wbg_ptr, m);
        return ret !== 0;
    }
    /**
     * @returns {string}
     */
    overflow() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_overflow(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Number of accepted activations waiting for a successful binding commit.
     * @returns {number}
     */
    pending_ui_binding_activations() {
        const ret = wasm.runtime_pending_ui_binding_activations(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} w
     * @param {number} h
     * @param {number} s
     * @returns {Uint8Array}
     */
    pixels(w, h, s) {
        const ret = wasm.runtime_pixels(this.__wbg_ptr, w, h, s);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} kind
     */
    pointer(x, y, kind) {
        wasm.runtime_pointer(this.__wbg_ptr, x, y, kind);
    }
    /**
     * @param {Runtime} previous
     */
    preserve_interaction(previous) {
        _assertClass(previous, Runtime);
        wasm.runtime_preserve_interaction(this.__wbg_ptr, previous.__wbg_ptr);
    }
    /**
     * @param {string} key
     * @returns {boolean}
     */
    range_key(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtime_range_key(this.__wbg_ptr, ptr0, len0);
        return ret !== 0;
    }
    /**
     * @param {number} i
     * @returns {number}
     */
    range_value(i) {
        const ret = wasm.runtime_range_value(this.__wbg_ptr, i);
        return ret;
    }
    /**
     * @returns {Uint32Array}
     */
    raster_stats() {
        const ret = wasm.runtime_raster_stats(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Discard reconstructible CPU pixels after the GPU takes over. For multiple
     * controls, leaf rasters are created only with the root raster, so its
     * presence also gates this traversal on subsequent GPU frames.
     */
    release_cpu_cache() {
        wasm.runtime_release_cpu_cache(this.__wbg_ptr);
    }
    /**
     * @returns {number}
     */
    render_height() {
        const ret = wasm.runtime_render_height(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    render_width() {
        const ret = wasm.runtime_render_width(this.__wbg_ptr);
        return ret;
    }
    /**
     * Proximity reaches sibling controls even when the pointer is outside all hits.
     * @param {number} x
     * @param {number} y
     * @param {boolean} present
     */
    reveal_pointer(x, y, present) {
        wasm.runtime_reveal_pointer(this.__wbg_ptr, x, y, present);
    }
    /**
     * @param {number} dx
     * @param {number} dy
     */
    scroll(dx, dy) {
        wasm.runtime_scroll(this.__wbg_ptr, dx, dy);
    }
    /**
     * @returns {Float32Array}
     */
    scroll_offset() {
        const ret = wasm.runtime_scroll_offset(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {boolean}
     */
    scrollable() {
        const ret = wasm.runtime_scrollable(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {boolean} reduced
     */
    set_reduced_motion(reduced) {
        wasm.runtime_set_reduced_motion(this.__wbg_ptr, reduced);
    }
    /**
     * Synchronizes two-way `<->` bindings (`value`, `checked`, `selected`) from the live runtime
     * back into the retained Rust `.ui` `Document`, re-rendering the scene while preserving focus
     * and active text/slider interaction. Returns `true` after a successful scene rebuild.
     * @returns {boolean}
     */
    sync_ui_bindings() {
        const ret = wasm.runtime_sync_ui_bindings(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @returns {Float32Array}
     */
    text_caret_bounds() {
        const ret = wasm.runtime_text_caret_bounds(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {boolean}
     */
    text_editing() {
        const ret = wasm.runtime_text_editing(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {string} text
     * @returns {boolean}
     */
    text_insert(text) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtime_text_insert(this.__wbg_ptr, ptr0, len0);
        return ret !== 0;
    }
    /**
     * @param {string} key
     * @param {boolean} shift
     * @param {boolean} command
     * @returns {boolean}
     */
    text_key(key, shift, command) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtime_text_key(this.__wbg_ptr, ptr0, len0, shift, command);
        return ret !== 0;
    }
    /**
     * @param {string} text
     */
    text_preedit(text) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.runtime_text_preedit(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @returns {string}
     */
    text_selected() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_text_selected(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} i
     * @returns {string}
     */
    text_value(i) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_text_value(this.__wbg_ptr, i);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} dt
     * @returns {boolean}
     */
    tick(dt) {
        const ret = wasm.runtime_tick(this.__wbg_ptr, dt);
        return ret !== 0;
    }
    /**
     * Exports the current state of the retained Rust `.ui` `Document` as a JSON string.
     * @returns {string}
     */
    ui_state_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.runtime_ui_state_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Float32Array}
     */
    viewport() {
        const ret = wasm.runtime_viewport(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    visual_revision() {
        const ret = wasm.runtime_visual_revision(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    width() {
        const ret = wasm.runtime_width(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) Runtime.prototype[Symbol.dispose] = Runtime.prototype.free;
exports.Runtime = Runtime;

/**
 * Exclusive selection for indexed radio, tab, and navigation items.
 */
class SelectionValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SelectionValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_selectionvalue_free(ptr, 0);
    }
    /**
     * @param {number} length
     * @param {number} selected
     */
    constructor(length, selected) {
        const ret = wasm.selectionvalue_new(length, selected);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        SelectionValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} delta
     * @param {boolean} wrap
     * @returns {number}
     */
    next(delta, wrap) {
        const ret = wasm.selectionvalue_next(this.__wbg_ptr, delta, wrap);
        return ret;
    }
    /**
     * -1 clears the selection. Other indices must belong to the group.
     * @param {number} index
     * @returns {number}
     */
    select(index) {
        const ret = wasm.selectionvalue_select(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @returns {number}
     */
    selected() {
        const ret = wasm.selectionvalue_selected(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) SelectionValue.prototype[Symbol.dispose] = SelectionValue.prototype.free;
exports.SelectionValue = SelectionValue;

class TextValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TextValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_textvalue_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    anchor() {
        const ret = wasm.textvalue_anchor(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {boolean}
     */
    backspace() {
        const ret = wasm.textvalue_backspace(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    can_redo() {
        const ret = wasm.textvalue_can_redo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    can_undo() {
        const ret = wasm.textvalue_can_undo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    caret() {
        const ret = wasm.textvalue_caret(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {boolean}
     */
    delete() {
        const ret = wasm.textvalue_delete(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {boolean} extend
     * @returns {boolean}
     */
    end(extend) {
        const ret = wasm.textvalue_end(this.__wbg_ptr, extend);
        return ret !== 0;
    }
    /**
     * @param {boolean} extend
     * @returns {boolean}
     */
    home(extend) {
        const ret = wasm.textvalue_home(this.__wbg_ptr, extend);
        return ret !== 0;
    }
    /**
     * @param {string} text
     * @returns {boolean}
     */
    insert(text) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.textvalue_insert(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @param {number} delta
     * @param {boolean} extend
     * @returns {boolean}
     */
    move(delta, extend) {
        const ret = wasm.textvalue_move(this.__wbg_ptr, delta, extend);
        return ret !== 0;
    }
    /**
     * @param {string} initial
     */
    constructor(initial) {
        const ptr0 = passStringToWasm0(initial, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.textvalue_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        TextValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {boolean}
     */
    redo() {
        const ret = wasm.textvalue_redo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    select_all() {
        const ret = wasm.textvalue_select_all(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {string}
     */
    selected_text() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.textvalue_selected_text(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} anchor
     * @param {number} caret
     * @returns {boolean}
     */
    set_selection(anchor, caret) {
        const ret = wasm.textvalue_set_selection(this.__wbg_ptr, anchor, caret);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @returns {boolean}
     */
    undo() {
        const ret = wasm.textvalue_undo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {string}
     */
    value() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.textvalue_value(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) TextValue.prototype[Symbol.dispose] = TextValue.prototype.free;
exports.TextValue = TextValue;

class ToggleValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ToggleValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_togglevalue_free(ptr, 0);
    }
    /**
     * @param {boolean} initial
     */
    constructor(initial) {
        const ret = wasm.togglevalue_new(initial);
        this.__wbg_ptr = ret;
        ToggleValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {boolean}
     */
    toggle() {
        const ret = wasm.togglevalue_toggle(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    value() {
        const ret = wasm.togglevalue_value(this.__wbg_ptr);
        return ret !== 0;
    }
}
if (Symbol.dispose) ToggleValue.prototype[Symbol.dispose] = ToggleValue.prototype.free;
exports.ToggleValue = ToggleValue;

/**
 * Preorder tree whose stable IDs are row indices. Branch flags describe actual
 * children; empty folders are not expandable in the current pure tree model.
 */
class TreeValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TreeValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_treevalue_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    down() {
        const ret = wasm.treevalue_down(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {number} index
     * @returns {boolean}
     */
    expanded(index) {
        const ret = wasm.treevalue_expanded(this.__wbg_ptr, index);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    left() {
        const ret = wasm.treevalue_left(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {Int32Array} parents
     * @param {Uint32Array} branches
     */
    constructor(parents, branches) {
        const ptr0 = passArray32ToWasm0(parents, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray32ToWasm0(branches, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.treevalue_new(ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        TreeValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {boolean}
     */
    right() {
        const ret = wasm.treevalue_right(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {number} index
     * @returns {number}
     */
    select(index) {
        const ret = wasm.treevalue_select(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @returns {number}
     */
    selected() {
        const ret = wasm.treevalue_selected(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} index
     * @returns {boolean}
     */
    toggle(index) {
        const ret = wasm.treevalue_toggle(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @returns {boolean}
     */
    up() {
        const ret = wasm.treevalue_up(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {Uint32Array}
     */
    visible() {
        const ret = wasm.treevalue_visible(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) TreeValue.prototype[Symbol.dispose] = TreeValue.prototype.free;
exports.TreeValue = TreeValue;

class VirtualListValue {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        VirtualListValueFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_virtuallistvalue_free(ptr, 0);
    }
    /**
     * @param {number} delta
     * @returns {number}
     */
    move_by(delta) {
        const ret = wasm.virtuallistvalue_move_by(this.__wbg_ptr, delta);
        return ret;
    }
    /**
     * @param {number} item_count
     * @param {number} item_height
     * @param {number} viewport_height
     * @param {number} overscan
     */
    constructor(item_count, item_height, viewport_height, overscan) {
        const ret = wasm.virtuallistvalue_new(item_count, item_height, viewport_height, overscan);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        VirtualListValueFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {number}
     */
    scroll_y() {
        const ret = wasm.virtuallistvalue_scroll_y(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} index
     * @returns {number}
     */
    select(index) {
        const ret = wasm.virtuallistvalue_select(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @returns {number}
     */
    selected() {
        const ret = wasm.virtuallistvalue_selected(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} scroll_y
     * @returns {number}
     */
    set_scroll_y(scroll_y) {
        const ret = wasm.virtuallistvalue_set_scroll_y(this.__wbg_ptr, scroll_y);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @returns {number}
     */
    total_height() {
        const ret = wasm.virtuallistvalue_total_height(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Uint32Array}
     */
    visible_range() {
        const ret = wasm.virtuallistvalue_visible_range(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) VirtualListValue.prototype[Symbol.dispose] = VirtualListValue.prototype.free;
exports.VirtualListValue = VirtualListValue;

/**
 * Shaped single-line metrics (`[width, height, glyph_count]`) using ligature/BiDi/fallback shaping.
 * @param {string} value
 * @param {number} font_size
 * @returns {Float32Array}
 */
function shaped_text_metrics(value, font_size) {
    const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.shaped_text_metrics(ptr0, len0, font_size);
    var v2 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
    return v2;
}
exports.shaped_text_metrics = shaped_text_metrics;

/**
 * Logical single-line metrics from the same font as the vector text renderer.
 * @param {string} value
 * @param {number} font_size
 * @returns {Float32Array}
 */
function text_metrics(value, font_size) {
    const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.text_metrics(ptr0, len0, font_size);
    var v2 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
    return v2;
}
exports.text_metrics = text_metrics;
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_string_get_71bb4348194e31f0: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_ea4887a5f8f9a9db: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./forma_bg.js": import0,
    };
}

const ButtonFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_button_free(ptr, 1));
const CheckValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_checkvalue_free(ptr, 1));
const CodeEditorValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_codeeditorvalue_free(ptr, 1));
const CommandPaletteValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_commandpalettevalue_free(ptr, 1));
const DataTableValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_datatablevalue_free(ptr, 1));
const DateTimeValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_datetimevalue_free(ptr, 1));
const RangeValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_rangevalue_free(ptr, 1));
const RichTextValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_richtextvalue_free(ptr, 1));
const RuntimeFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_runtime_free(ptr, 1));
const SelectionValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_selectionvalue_free(ptr, 1));
const TextValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_textvalue_free(ptr, 1));
const ToggleValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_togglevalue_free(ptr, 1));
const TreeValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_treevalue_free(ptr, 1));
const VirtualListValueFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_virtuallistvalue_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function getArrayF32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

let cachedFloat32ArrayMemory0 = null;
function getFloat32ArrayMemory0() {
    if (cachedFloat32ArrayMemory0 === null || cachedFloat32ArrayMemory0.byteLength === 0) {
        cachedFloat32ArrayMemory0 = new Float32Array(wasm.memory.buffer);
    }
    return cachedFloat32ArrayMemory0;
}

let cachedFloat64ArrayMemory0 = null;
function getFloat64ArrayMemory0() {
    if (cachedFloat64ArrayMemory0 === null || cachedFloat64ArrayMemory0.byteLength === 0) {
        cachedFloat64ArrayMemory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64ArrayMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArray32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getUint32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayF64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getFloat64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    for (let i = 0; i < array.length; i++) {
        const add = addToExternrefTable0(array[i]);
        getDataViewMemory0().setUint32(ptr + 4 * i, add, true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
function decodeText(ptr, len) {
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/forma_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasmInstance = new WebAssembly.Instance(wasmModule, __wbg_get_imports());
let wasm = wasmInstance.exports;
wasm.__wbindgen_start();
