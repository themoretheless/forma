/* tslint:disable */
/* eslint-disable */

export class Button {
    free(): void;
    [Symbol.dispose](): void;
    action(): string;
    activate(): void;
    background_color(): string;
    bounds(): Float32Array;
    clicks(): number;
    clipped(): boolean;
    /**
     * Studio paints its rounded artboard background separately from children.
     * This avoids clipping overflowing children just to round the background.
     */
    content_pixels(width: number, height: number, scale: number): Uint8Array;
    disabled(): boolean;
    focus(focused: boolean): void;
    frame_radius(): number;
    gpu_commands(scale: number, background: boolean): Float32Array;
    gpu_edges(scale: number, background: boolean): Float32Array;
    gpu_paints(): Float32Array;
    gpu_params(width: number, height: number, scale: number, opaque: boolean): Float32Array;
    gpu_tiles(width: number, height: number, scale: number, background: boolean): Uint32Array;
    height(): number;
    hit(x: number, y: number): boolean;
    is_animating(): boolean;
    is_focused(): boolean;
    key(): string;
    /**
     * Shared web/native keyboard gesture: 1 = Space, 2 = Enter.
     * Repeats and unmatched releases cannot activate; blur cancels the gesture.
     */
    key_event(key: number, pressed: boolean, repeat: boolean): void;
    label(): string;
    load(source: string): void;
    load_component(source: string, component: string): void;
    constructor();
    overflow(): string;
    pixels(width: number, height: number, scale: number): Uint8Array;
    pointer(x: number, y: number, kind: number): void;
    preserve_interaction(previous: Button): void;
    raster_stats(): Uint32Array;
    release_cpu_cache(): void;
    render_height(): number;
    render_width(): number;
    /**
     * Proximity only: does not change hover, focus, pointer capture or actions.
     */
    reveal_pointer(x: number, y: number, present: boolean): void;
    scroll(dx: number, dy: number): void;
    scroll_offset(): Float32Array;
    scrollable(): boolean;
    set_reduced_motion(reduced: boolean): void;
    tick(delta_ms: number): boolean;
    viewport(): Float32Array;
    visual_revision(): number;
    width(): number;
}

export class CheckValue {
    free(): void;
    [Symbol.dispose](): void;
    activate(): number;
    /**
     * State: 0 = unchecked, 1 = checked, 2 = mixed.
     */
    constructor(initial: number, tristate: boolean);
    state(): number;
}

export class CodeEditorValue {
    free(): void;
    [Symbol.dispose](): void;
    cursor_column(): number;
    cursor_line(): number;
    indent(): boolean;
    line_count(): number;
    constructor(initial: string, tab_size: number);
    token_count(): number;
    value(): string;
}

export class CommandPaletteValue {
    free(): void;
    [Symbol.dispose](): void;
    active_id(): string;
    filtered(): Uint32Array;
    move_selection(delta: number): string;
    constructor(titles: string[]);
    set_query(query: string): void;
}

export class DataTableValue {
    free(): void;
    [Symbol.dispose](): void;
    move_selection(delta: number): number;
    constructor(column_widths: Float64Array, row_count: number, row_height: number, viewport_height: number);
    resize_column(column: number, width: number): number;
    select_row(row: number, additive: boolean): void;
    set_filter(filter: string): void;
    set_scroll_y(scroll_y: number): number;
    toggle_sort(column: number): number;
    virtual_window(overscan: number): Uint32Array;
}

export class DateTimeValue {
    free(): void;
    [Symbol.dispose](): void;
    calendar_grid(): Uint8Array;
    format_date(): string;
    format_iso(): string;
    constructor(year: number, month: number, day: number, hour: number, minute: number);
    step_days(delta: number): string;
    step_months(delta: number): string;
}

export class RangeValue {
    free(): void;
    [Symbol.dispose](): void;
    fraction(): number;
    constructor(min: number, max: number, step: number, value: number);
    set(value: number): number;
    set_fraction(fraction: number): number;
    step_by(steps: number): number;
    value(): number;
}

export class RichTextValue {
    free(): void;
    [Symbol.dispose](): void;
    clear_formatting(): void;
    heading_level(): number;
    constructor(markdown: string);
    set_heading_level(level: number): void;
    text(): string;
    to_markdown(): string;
    toggle_bold(): boolean;
    toggle_code(): boolean;
    toggle_italic(): boolean;
}

export class Runtime {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Exports the AccessKit-compatible semantic accessibility tree as a compact JSON snapshot.
     */
    accessibility_tree_json(): string;
    action(): string;
    activate(): void;
    activate_control(i: number): void;
    active_modal(): number;
    background_color(): string;
    bounds(): Float32Array;
    /**
     * Explicitly discard buffered activations, clearing an overflow refusal.
     * Widget values remain available for the next binding synchronization.
     */
    cancel_ui_binding_activations(): number;
    clicks(): number;
    clipped(): boolean;
    close_modal(m: number): boolean;
    /**
     * Compile a UI project to a versioned transport in Rust for a later runtime load.
     */
    static compile_ui_scene_artifact(files_json: string, entry_file: string, state_json: string): string;
    content_pixels(w: number, h: number, s: number): Uint8Array;
    control_action(i: number): string;
    /**
     * Hidden by a closed layer or covered by another layer's backdrop.
     */
    control_blocked(i: number): boolean;
    control_bounds(i: number): Float32Array;
    control_clicks(i: number): number;
    control_count(): number;
    control_disabled(i: number): boolean;
    control_editable(i: number): boolean;
    control_focused(i: number): boolean;
    control_hovered(i: number): boolean;
    control_interactive(i: number): boolean;
    control_key(i: number): string;
    control_label(i: number): string;
    /**
     * Layer index of a control, -1 for the base scene.
     */
    control_modal(i: number): number;
    disabled(): boolean;
    dismiss_count(): number;
    /**
     * Escape or a press on the backdrop: closes the layer and records a
     * dismissal so hosts can run the layer's `dismissed` handler.
     */
    dismiss_modal(m: number): boolean;
    dismissed_index(): number;
    event_index(): number;
    focus(value: boolean): void;
    focus_control(index: number): boolean;
    /**
     * Move within the scene; false lets the browser transfer focus outside it.
     */
    focus_next(reverse: boolean): boolean;
    focused_index(): number;
    frame_radius(): number;
    geometry_revision(): number;
    gpu_commands(s: number, b: boolean): Float32Array;
    gpu_edges(s: number, b: boolean): Float32Array;
    gpu_paints(): Float32Array;
    gpu_params(w: number, h: number, s: number, o: boolean): Float32Array;
    gpu_tiles(w: number, h: number, s: number, b: boolean): Uint32Array;
    height(): number;
    hit(x: number, y: number): boolean;
    hit_index(x: number, y: number): number;
    is_animating(): boolean;
    is_focused(): boolean;
    key(): string;
    /**
     * Keys: 1 = Space, 2 = Enter, 3 = Escape. Escape dismisses the active
     * layer even while its text field is being edited.
     */
    key_event(key: number, pressed: boolean, repeat: boolean): void;
    label(): string;
    /**
     * Control bounds change on scroll or source replacement. Paint and
     * text-content changes do not invalidate these bounds.
     */
    layout_revision(): number;
    load(source: string): void;
    load_component(source: string, component: string): void;
    /**
     * Load a complete artifact atomically through the Rust parser/runtime.
     */
    load_scene_artifact(json: string): void;
    /**
     * Compiles a JSON map of `.ui`/`.svg` project files directly in Rust and loads the rendered scene.
     */
    load_ui_files_json(files_json: string, entry_file: string, state_json: string): void;
    modal_action(m: number): string;
    modal_bounds(m: number): Float32Array;
    modal_count(): number;
    modal_dismissible(m: number): boolean;
    modal_is_open(m: number): boolean;
    modal_key(m: number): string;
    constructor();
    open_modal(m: number): boolean;
    overflow(): string;
    /**
     * Number of accepted activations waiting for a successful binding commit.
     */
    pending_ui_binding_activations(): number;
    pixels(w: number, h: number, s: number): Uint8Array;
    pointer(x: number, y: number, kind: number): void;
    preserve_interaction(previous: Runtime): void;
    range_key(key: string): boolean;
    range_value(i: number): number;
    raster_stats(): Uint32Array;
    /**
     * Discard reconstructible CPU pixels after the GPU takes over. For multiple
     * controls, leaf rasters are created only with the root raster, so its
     * presence also gates this traversal on subsequent GPU frames.
     */
    release_cpu_cache(): void;
    render_height(): number;
    render_width(): number;
    /**
     * Proximity reaches sibling controls even when the pointer is outside all hits.
     */
    reveal_pointer(x: number, y: number, present: boolean): void;
    scroll(dx: number, dy: number): void;
    scroll_offset(): Float32Array;
    scrollable(): boolean;
    set_reduced_motion(reduced: boolean): void;
    /**
     * Synchronizes two-way `<->` bindings (`value`, `checked`, `selected`) from the live runtime
     * back into the retained Rust `.ui` `Document`, re-rendering the scene while preserving focus
     * and active text/slider interaction. Returns `true` after a successful scene rebuild.
     */
    sync_ui_bindings(): boolean;
    text_caret_bounds(): Float32Array;
    text_editing(): boolean;
    text_insert(text: string): boolean;
    text_key(key: string, shift: boolean, command: boolean): boolean;
    text_preedit(text: string): void;
    text_selected(): string;
    text_value(i: number): string;
    tick(dt: number): boolean;
    /**
     * Exports the current state of the retained Rust `.ui` `Document` as a JSON string.
     */
    ui_state_json(): string;
    viewport(): Float32Array;
    visual_revision(): number;
    width(): number;
}

/**
 * Exclusive selection for indexed radio, tab, and navigation items.
 */
export class SelectionValue {
    free(): void;
    [Symbol.dispose](): void;
    constructor(length: number, selected: number);
    next(delta: number, wrap: boolean): number;
    /**
     * -1 clears the selection. Other indices must belong to the group.
     */
    select(index: number): number;
    selected(): number;
}

export class TextValue {
    free(): void;
    [Symbol.dispose](): void;
    anchor(): number;
    backspace(): boolean;
    can_redo(): boolean;
    can_undo(): boolean;
    caret(): number;
    delete(): boolean;
    end(extend: boolean): boolean;
    home(extend: boolean): boolean;
    insert(text: string): boolean;
    move(delta: number, extend: boolean): boolean;
    constructor(initial: string);
    redo(): boolean;
    select_all(): boolean;
    selected_text(): string;
    set_selection(anchor: number, caret: number): boolean;
    undo(): boolean;
    value(): string;
}

export class ToggleValue {
    free(): void;
    [Symbol.dispose](): void;
    constructor(initial: boolean);
    toggle(): boolean;
    value(): boolean;
}

/**
 * Preorder tree whose stable IDs are row indices. Branch flags describe actual
 * children; empty folders are not expandable in the current pure tree model.
 */
export class TreeValue {
    free(): void;
    [Symbol.dispose](): void;
    down(): boolean;
    expanded(index: number): boolean;
    left(): boolean;
    constructor(parents: Int32Array, branches: Uint32Array);
    right(): boolean;
    select(index: number): number;
    selected(): number;
    toggle(index: number): boolean;
    up(): boolean;
    visible(): Uint32Array;
}

export class VirtualListValue {
    free(): void;
    [Symbol.dispose](): void;
    move_by(delta: number): number;
    constructor(item_count: number, item_height: number, viewport_height: number, overscan: number);
    scroll_y(): number;
    select(index: number): number;
    selected(): number;
    set_scroll_y(scroll_y: number): number;
    total_height(): number;
    visible_range(): Uint32Array;
}

/**
 * Shaped single-line metrics (`[width, height, glyph_count]`) using ligature/BiDi/fallback shaping.
 */
export function shaped_text_metrics(value: string, font_size: number): Float32Array;

/**
 * Logical single-line metrics from the same font as the vector text renderer.
 */
export function text_metrics(value: string, font_size: number): Float32Array;
